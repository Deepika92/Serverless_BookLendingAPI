'use strict';

const uuid = require('uuid');
const AWS = require('aws-sdk'); 

AWS.config.setPromisesDependency(require('bluebird'));

const dynamoDb = new AWS.DynamoDB.DocumentClient();


module.exports.create = (event, context, callback) => {
  const requestBody = JSON.parse(event.body);
  const author = requestBody.author;
  const name = requestBody.name;
 
  

  if (typeof name !== 'string' || typeof author !== 'string') {
    console.error('Validation Failed');
    callback(new Error('Couldn\'t create the book.'));
    return;
  }

  createbook(bookdetails(name, author))
    .then(res => {
      callback(null, {
        statusCode: 200,
        body: JSON.stringify({
          message: `Sucessfully created the book entry${name}`,
          id: res.id
        })
      });
    })
    .catch(err => {
      console.log(err);
      callback(null, {
        statusCode: 500,
        body: JSON.stringify({
          message: `Unable to create the book entry ${name}`
        })
      })
    });
};


const createbook = book => {
  console.log('Book entry');
  const details = {
    TableName: process.env.BOOK_TABLE,
    Item: book,
  };
  return dynamoDb.put(bookdetails).promise()
    .then(res => book);
};

const bookdetails = (name, author) => {
  const timestamp = new Date().getTime();
  return {
    id: uuid.v1(),
    name: name,
    author: author,
    submittedAt: timestamp,
    updatedAt: timestamp,
  };
};
